
from numpy import random
from pymd5 import md5, padding
#might want to randomly generate number and try hashing that and matching to 273D27 (23)

def gen_password(length, collections_of_characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!~&`\'<>/?'):
    characters = list(collections_of_characters) #break up the string into its constituents

    password = [random.choice(characters) for _ in range(0, length)]
    return "".join(password)
answer = ''
length = 1
iteration = 0

while True:
    length = random.randint(1,64)
    to_try = gen_password(length)
    result = md5(to_try).hexdigest()
    result = str(result)
    if (result.find('273d27')!= -1):
        answer = to_try
        if (result.index('273d27')%2 == 0): break
            
    iteration += 1
    if iteration%10000==0: print ('Iterations (10\'000s): ' + str(int(iteration/10000)))

print ('Password: ' + str(answer))
print ('Hash: ' + str(result))


        

